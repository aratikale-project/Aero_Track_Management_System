package com.airline.service;

import com.airline.model.User;

public interface UserService {
    void registerUser(User user);
    User loginUser(User user);
}
