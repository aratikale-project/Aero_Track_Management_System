package com.airline.service;

import com.airline.model.Booking;
import com.airline.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Override
    public String bookFlight(Booking booking) {
        bookingRepository.save(booking);
        return "Booking confirmed!";
    }
}
