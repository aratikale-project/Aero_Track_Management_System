package com.airline.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.model.Flight;
import com.airline.repository.FlightRepository;

@Service
public class FlightService {

    @Autowired
    private FlightRepository flightRepository;

    // Method to search for flights based on the origin, destination, and departure date
    public List<Flight> searchFlights(String origin, String destination, Date departureDate) {
        return flightRepository.findByOriginAndDestinationAndDepartureDate(origin, destination, departureDate);
    }

    // Method to add a new flight to the system
    public Flight addFlight(Flight flight) {
        return flightRepository.save(flight);  // Save the flight in the database
    }
}
