package com.airline.service;

import com.airline.model.Booking;

public interface BookingService {
    String bookFlight(Booking booking);
}
