package com.airline.service;

import com.airline.model.User;
import com.airline.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void registerUser(User user) {
        userRepository.save(user);  // Save user to the database
    }

    @Override
    public User loginUser(User user) {
        // Try to find the user by username
        User foundUser = userRepository.findByUsername(user.getUsername());
        if (foundUser != null && foundUser.getPassword().equals(user.getPassword())) {
            return foundUser;  // Successful login
        }
        return null;  // Invalid credentials
    }
}
