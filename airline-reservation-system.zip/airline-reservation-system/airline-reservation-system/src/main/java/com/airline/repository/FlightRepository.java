package com.airline.repository;

import com.airline.model.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Date;

public interface FlightRepository extends JpaRepository<Flight, Long> {

    // Search based on origin, destination, and date
    List<Flight> findByOriginAndDestinationAndDepartureDate(String origin, String destination, Date departureDate);

}
